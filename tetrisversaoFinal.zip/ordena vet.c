#include<stdio.h>
int main(){
	int vet[]={  2,3,6,5,1,543,5,84,48,8,82,56,5,549,416,4,3};
	int vetp[]={ 0,1,0,1,0,0  ,1, 2, 1,0,1 ,0 ,1,0  ,1  ,1,0};
	int i ,j,aux;
		printf("\n  %d\n",sizeof(vet)/sizeof(int));
	for(i=0;i<sizeof(vet)/sizeof(int);i++){
		printf("(%03d,%01d)  ",vet[i],vetp[i]);
	}
		printf("\n \n");
		
	for(i=0;i<sizeof(vet)/sizeof(int);i++){
		for(j=0;j<sizeof(vet)/sizeof(int);j++){
			if(vetp[i]&& vetp[j]){
				if(vet[i]>vet[j]){
					aux = vet[i];
					vet[i]=  vet[j];
					vet[j] = aux;
					aux = vetp[i];
					vetp[i] = vetp[j];
					vetp[j] = aux;
				}
			}else if( vetp[i]){
					aux = vet[i];
					vet[i]=  vet[j];
					vet[j] = aux;
					aux = vetp[i];
					vetp[i] = vetp[j];
					vetp[j] = aux;
			}
		}
	}
		for(i=0;i<sizeof(vet)/sizeof(int);i++){
		printf("(%03d,%01d)  ",vet[i],vetp[i]);
	}
		printf("\n ");
	return 0;
}
