
#include <stdio.h>
#include <conio2.h>
#include <stdlib.h>
#define SETA_DIREITA 77
#define SETA_ESQUERDA 75
#define SETA_CIMA 72
#define SETA_BAIXO 80
#define ENTER 13
typedef struct{
	char pix[16][16];
}IMG;
void printaImg(char img[][16]){
            textbackground(WHITE);
	system("cls");
	int x0 = 15, y = 3, i,j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            gotoxy(x0+ 1* j, y+i);
            textbackground(img[i][j]);
            if(!img[i][j]){
            textbackground(WHITE);
			}
            if(img[i][j]==-1){
            textbackground(BLACK);
			}
            
            printf(" ");

        }
       
    }
}
void printforma(int x,int y, IMG m){
	textbackground(BLACK);
	system("cls");
	int i,j;
   for(i=0;i<16;i++){
   	for(j=0;j<16;j++){
   		gotoxy(x + 4 * j, y + i);
        textbackground(m.pix[i][j]);
        printf(" %02d ", m.pix[i][j]);
	   }
   }
}

char getIMG(char *IMGname, IMG *img) {
    FILE *f;
    f = fopen(IMGname, "rb");
    if (!f) {
        return 0;
    }
    fread(img->pix, sizeof(char), 16*16, f);
    fclose(f);
}
int main() {
	IMG m={0
	};
	getIMG("pacman5.bin",&m);
	printaImg(m.pix);
//	return 0;
 FILE *f;
   f = fopen("pacman5.bin","wb");
	char *name="nN.ilh";
    int i = 0, j = 0, sair = 1;
char c;


    int x0 = 15, y = 3, x = x0;
   //printaImg(m.pix);
     printforma(x,y,m);
    for (; sair;) {
        gotoxy(x + 4 * j, y + i);
        textbackground(m.pix[i][j]);
        printf(" %02d ", m.pix[i][j]);
        gotoxy(90,5);
         textbackground(BLACK);
        printf("[%d][%d]",i+1,j+1);
        if (kbhit()) {
        	c = getch();
        	if(c == -32){
        		 c = getch();
                switch (c) {
                    case SETA_BAIXO:
                        c = 's';
                        break;
                    case SETA_CIMA:
                        c = 'w';
                        break;
                    case SETA_DIREITA:
                        c = 'd';
                        break;
                    case SETA_ESQUERDA:
                        c = 'a';
                        break;
                    default :
                        break;
                }
			}
            switch (c) {
                case 'w':
                case 'W':
                    if (i > 0) {
                        i--;
                    }
                    break;
                case 'y':
                case 'Y':
                   printaImg(m.pix);
                    getch();
                    printforma(x,y,m);
                    break;
                case 's':
                case 'S':
                    if (i < 15) {
                        i++;
                    }
                    break;
                case 'a':
                case 'A':
                    if (j > 0) {
                        j--;
                    }
                    break;
                case 'd':
                case 'D':
                    if (j < 15) {
                        j++;
                    }
                    break;
                case 'k':
                case 'K':
                    m.pix[i][j]--;
                    break;
                case 'l':
                case 'L':
                    m.pix[i][j]++;
                    break;
                case ' ':
                case 'q':
                    sair = 0;
                    break;
                case '0':
                    m.pix[i][j] = 0;
                    break;
                case '1':
                    m.pix[i][j] = 1;
                    break;
                case '2':
                    m.pix[i][j] = 12;
                    break;
                case '3':
                    m.pix[i][j] = 3;
                    break;
                case '4':
                    m.pix[i][j] = 4;
                    break;
                case '5':
                    m.pix[i][j] = 5;
                    break;
                case '6':
                    m.pix[i][j] = 6;
                    break;
                case '7':
                    m.pix[i][j] = 7;
                    break;
				case '8':
                    m.pix[i][j] = 8;
                    break;
                case '9':
                    m.pix[i][j] = 9;
                    break;
                case '/':
                    m.pix[i][j] = 15;
                    break;
                case '-':
                    m.pix[i][j] = -1;
                    break;
                    case '*':
            	m.pix[i][j] = 14;
                    break;
                
            }
        }
    }
    textbackground(BLACK);
    
  printf("%p\n",f);
   printf("%d",fwrite(&m,sizeof(IMG),1,f));
   fclose(f);
  /* 
    f = fopen(name,"w");
    printf("%p",f);
    getch();
    system("cls");
    fprintf(f,"char img[16][16] = {\n{");
    printf("char img[16][16] = {\n{");
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            if (j < 15) {
                fprintf(f,"%d, ", m.pix[i][j]);
                printf("%d, ", m.pix[i][j]);
            } else {
                fprintf(f,"%d", m.pix[i][j]);
                printf("%d", m.pix[i][j]);
            }
        }
        if (i < 15) {
            fprintf(f,"},\n{");
            printf("},\n{");
        } else {
            fprintf(f,"}};");
            printf("}};");
        }
    }
    fclose(f);*/
}
